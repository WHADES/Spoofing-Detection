function [trackResults, channel]= tracking(fid, channel, settings)
% Performs code and carrier tracking for all channels.
%
%[trackResults, channel] = tracking(fid, channel, settings)
%
%   Inputs:
%       fid             - file identifier of the signal record.
%       channel         - PRN, carrier frequencies and code phases of all
%                       satellites to be tracked (prepared by preRum.m from
%                       acquisition results).
%       settings        - receiver settings.
%    ���룬fid,�źű�ʶ��
%          channel,�ŵ�
%          settings,���ջ�����
%   Outputs:
%       trackResults    - tracking results (structure array). Contains
%                       in-phase prompt outputs and absolute starting 
%                       positions of spreading codes, together with other
%                       observation data from the tracking loops. All are
%                       saved every millisecond.
%���ٽ�����ṹ���飩��
% ����ͬ����ʾ���   ��   C/A��ľ�����ʼλ�ã�  �Լ����Ը���ѭ����tracking loops���������۲����ݡ�
% ��������ÿ���뱣��һ�Ρ�
%--------------------------------------------------------------------------
%                           SoftGNSS v3.0
% 
% Copyright (C) Dennis M. Akos
% Written by Darius Plausinaitis and Dennis M. Akos
% Based on code by DMAkos Oct-1999
%--------------------------------------------------------------------------
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
%USA.
%--------------------------------------------------------------------------

%CVS record:
%$Id: tracking.m,v 1.14.2.32 2007/01/30 09:45:12 dpl Exp $

%% Initialize result structure ============================================

% Channel status
trackResults.status         = '-';      % No tracked signal, or lost lock

% The absolute sample in the record of the C/A code start:
%C/A������Բ��������
trackResults.absoluteSample = zeros(1, settings.msToProcess);

% Freq of the C/A code:
trackResults.codeFreq       = inf(1, settings.msToProcess);

% Frequency of the tracked carrier wave:
trackResults.carrFreq       = inf(1, settings.msToProcess);

% Outputs from the correlators (In-phase):
trackResults.I_P            = zeros(1, settings.msToProcess);
trackResults.I_E            = zeros(1, settings.msToProcess);
trackResults.I_L            = zeros(1, settings.msToProcess);

% Outputs from the correlators (Quadrature-phase):
trackResults.Q_E            = zeros(1, settings.msToProcess);
trackResults.Q_P            = zeros(1, settings.msToProcess);
trackResults.Q_L            = zeros(1, settings.msToProcess);

% Loop discriminators
trackResults.dllDiscr       = inf(1, settings.msToProcess);
trackResults.dllDiscrFilt   = inf(1, settings.msToProcess);
trackResults.pllDiscr       = inf(1, settings.msToProcess);
trackResults.pllDiscrFilt   = inf(1, settings.msToProcess);

%--- Copy initial settings for all channels -------------------------------
% ��������ͨ���ĳ�ʼ����
trackResults = repmat(trackResults, 1, settings.numberOfChannels);

%% Initialize tracking variables ==========================================
%  load trackingResults          %������
codePeriods = settings.msToProcess;     % For GPS one C/A code is one ms
% codePeriods = 2*settings.msToProcess;     % �ҵĵ���2*37000
%--- DLL variables --------------------------------------------------------
%DLL���뻷����
% Define early-late offset (in chips)
earlyLateSpc = settings.dllCorrelatorSpacing;

% Summation interval
PDIcode = 0.001;

% Calculate filter coefficient values
[tau1code, tau2code] = calcLoopCoef(settings.dllNoiseBandwidth, ...
                                    settings.dllDampingRatio, ...
                                    1.0);

%--- PLL variables --------------------------------------------------------
%PLL���ز����ļ��໷����
% Summation interval
PDIcarr = 0.001;

% Calculate filter coefficient values
[tau1carr, tau2carr] = calcLoopCoef(settings.pllNoiseBandwidth, ...
                                    settings.pllDampingRatio, ...
                                    0.25);
hwb = waitbar(0,'Tracking...');


point_to_begin=2*ceil(settings.start_time*settings.samplingFreq)*2;%pointer to first value x2 for bytes�����ݶ�ȡ��ʼʱ���
%% Start processing channels ==============================================
for channelNr = 1:settings.numberOfChannels%��һ��2ԭ����1�����Ե�ʱ��ĳɵ�2���ڶ���2ԭ����settings.numberOfChannels
    
    % Only process if PRN is non zero (acquisition was successful)
    if (channel(channelNr).PRN ~= 0)
        % Save additional information - each channel's tracked PRN
        trackResults(channelNr).PRN     = channel(channelNr).PRN;
        trackResults(channelNr).status = 'T';
        % Move the starting point of processing. Can be used to start the
        % signal processing at any point in the data record (e.g. for long
        % records). In addition skip through that data file to start at the
        % appropriate sample (corresponding to code phase). Assumes sample
        % type is schar (or 1 byte per sample) 
%         �ƶ���������㡣 �����������ݼ�¼�е��κε㿪ʼ�źŴ��������磬���ڳ���¼���� 
%         ���⣬�����������ļ��Դ��ʵ���ʾ����ʼ����Ӧ�ڴ���׶Σ��� 
%         ����sampl����Ϊschar����ÿ��������һ���ֽڣ�
        fseek(fid, ...
              point_to_begin+ 4*(channel(channelNr).codePhase-1), ...
              'bof');%settings.skipNumberOfBytes + channel(channelNr).codePhase-10,

        % Get a vector with the C/A code sampled 1x/chip
        caCode = generateCAcode(channel(channelNr).PRN);
        save('caCode_first','caCode');
        % Then make it possible to do early and late versions
        caCode = [caCode(1023) caCode caCode(1)];
        save('caCode','caCode');
        %--- Perform various initializations ------------------------------

        % define initial code frequency basis of NCO ���ֿ��������������������������Ǻ����ź�
        codeFreq      = settings.codeFreqBasis;
        % define residual code phase (in chips)
        remCodePhase  = 0.0;
        % define carrier frequency which is used over whole tracking period
        %��������������������ʹ�õ��ز�Ƶ��
        carrFreq      = channel(channelNr).acquiredFreq;
        carrFreqBasis = channel(channelNr).acquiredFreq;
        % define residual carrier phase
        remCarrPhase  = 0.0;

        %code tracking loop parameters
        oldCodeNco   = 0.0;
        oldCodeError = 0.0;

        %carrier/Costas loop parameters
        oldCarrNco   = 0.0;
        oldCarrError = 0.0;

%% 
%=== Process the number of specified code periods =================
 for loopCnt =  1:codePeriods%loopCnt=1,��1ms������37000�Σ���������37S������
            
%% GUI update -------------------------------------------------------------
            % The GUI is updated every 50ms. This way Matlab GUI is still
            % responsive enough. At the same time Matlab is not occupied
            % all the time with GUI task.
            %GUI�û�ͼ�ν���
            if (rem(loopCnt, 50) == 0)
                try
                    waitbar(loopCnt/codePeriods, ...
                            hwb, ...
                            ['Tracking: Ch ', int2str(channelNr), ...
                            ' of ', int2str(settings.numberOfChannels), ...
                            '; PRN#', int2str(channel(channelNr).PRN), ...
                            '; Completed ',int2str(loopCnt), ...
                            ' of ', int2str(codePeriods), ' msec']);                       
                catch
                    % The progress bar was closed. It is used as a signal
                    % to stop, "cancel" processing. Exit.
                    disp('Progress bar closed, exiting...');
                    return
                end
            end

%% Read next block of data ------------------------------------------------            
            % Find the size of a "block" or code period in whole samples
            
            % Update the phasestep based on code freq (variable) and
            % sampling frequency (fixed)
%           �������������ҵ�һ�����顱��C/A�����ڵĴ�С��������Ƶ�ʣ��ɱ䣩�Ͳ���Ƶ�ʣ��̶���������λ����
            %C/A����λ����1023000/16367600=0.0625HZ
            codePhaseStep = codeFreq / settings.samplingFreq;%�����壺������ÿһ�������ĵ㣬����ʵ�ʶ೤�Ĳ�������ʱ�䣩��
            %blksize��һ��C/A�����ڵĲ�������16368
            blksize = ceil((settings.codeLength-remCodePhase) / codePhaseStep);
            count = 2*blksize;
            % Read in the appropriate number of samples to process this
            % interation 
            %�����ʵ����ȵ������Խ��и��٣�Ŀǰ������һ��C/A�����ڳ��ȣ�rawSignal��
            %fread����fid����
%             if (loopCnt == settings.msToProcess)
%               fseek(fid, ...
%               point_to_begin+ (4*channel(channelNr).codePhase-1), ...
%               'bof');%settings.skipNumberOfBytes + channel(channelNr).codePhase-10
%             end
            [rawSignal, samplesRead] = fread(fid, ...
                                             count, settings.dataType);
%           fprintf('��%d���ļ�fid:fid=%f\n',loopCnt,fid);
            
            rawSignal = rawSignal';  %transpose vector
            rawSignal = rawSignal(1:2:count-1)+1i*rawSignal(2:2:count);
%             rawSignal = cos(carrFreq)*rawSignal(1:2:count-1)+sin(carrFreq)*rawSignal(2:2:count);
            % If did not read in enough samples, then could be out of 
            % data - better exit 
%             fprintf('ͨ��%d,��%d��ѭ��\n',channelNr,loopCnt);
            if (samplesRead ~= count)
                disp('Not able to read the specified number of samples  for tracking, exiting!')
                fclose(fid);
                return
            end
%% Set up all the code phase tracking information -------------------------
            % Define index into early code vector
            %remCodePhase=0,earlyLateSpc=0.5(0.5����Ƭ)��codePhaseStepC/A����λ����1023000/16367600
            %blksize��������������һ��������C/A�����ڵĴ�С
%             [C/A����Ƭ��С-ʣ������λ/C/A���������][��1023-0��/C/A���������]
%             caCode = [caCode(1023) caCode caCode(1)];
            tcode       = (remCodePhase-earlyLateSpc) : ...
                          codePhaseStep : ...
                          ((blksize-1)*codePhaseStep+remCodePhase-earlyLateSpc);
            tcode2      = ceil(tcode) + 1;
            earlyCode   = caCode(tcode2);
%             save('earlyCode','earlyCode');
%             save('tcode','tcode');
            %������ǰ��
            % Define index into late code vector
            tcode       = (remCodePhase+earlyLateSpc) : ...
                          codePhaseStep : ...
                          ((blksize-1)*codePhaseStep+remCodePhase+earlyLateSpc);
            tcode2      = ceil(tcode) + 1;
            lateCode    = caCode(tcode2);
            
            % Define index into prompt code vector
            tcode       = remCodePhase : ...
                          codePhaseStep : ...
                          ((blksize-1)*codePhaseStep+remCodePhase);
            tcode2      = ceil(tcode) + 1;
            tcode2(1)   = 2;
            promptCode  = caCode(tcode2);
            
            remCodePhase = (tcode(blksize) + codePhaseStep) - 1023.0;

%% Generate the carrier frequency to mix the signal to baseband -----------
            time    = (0:blksize) ./ settings.samplingFreq;%ÿ���������ʱ����
            
            % Get the argument to sin/cos functions
            %��ȡsin / cos�����Ĳ���
            trigarg = ((carrFreq * 2.0 * pi) .* time) + remCarrPhase;
            remCarrPhase = rem(trigarg(blksize+1), (2 * pi));
            
            % Finally compute the signal to mix the collected data to bandband
            %�������ź��Խ��ռ��������ݻ�ϵ�Ƶ����
%             carrCos = cos(trigarg(1:blksize));
%             carrSin = sin(trigarg(1:blksize));
            carrsig = exp(1i .* trigarg(1:blksize));
%% Generate the six standard accumulated values ---------------------------
% ����������׼�ۼ�ֵ
% ��ϸ����tracking�Ľṹ�����������ô������һ����
            % First mix to baseband
            qBasebandSignal = real(carrsig .* rawSignal);
            iBasebandSignal = imag(carrsig .* rawSignal);

            % Now get early, late, and prompt values for each
            I_E = sum(earlyCode  .* iBasebandSignal);
            Q_E = sum(earlyCode  .* qBasebandSignal);
            I_P = sum(promptCode .* iBasebandSignal);
            Q_P = sum(promptCode .* qBasebandSignal);
            I_L = sum(lateCode   .* iBasebandSignal);
            Q_L = sum(lateCode   .* qBasebandSignal);
            %��Ҫ�Լ���취�����ز�
%% Find PLL error and update carrier NCO ----------------------------------

            % Implement carrier loop discriminator (phase
            % detector)�ز�Ƶ�����������ź��븴���ز��źŵ���λ��
            carrError = atan(Q_P / I_P) / (2.0 * pi);
            
            % Implement carrier loop filter and generate NCO command�ز�Ƶ��У��ֵ
            carrNco = oldCarrNco + (tau2carr/tau1carr) * ...
                (carrError - oldCarrError) + carrError * (PDIcarr/tau1carr);
            oldCarrNco   = carrNco;
            oldCarrError = carrError;

            % Modify carrier freq based on NCO command
            carrFreq = carrFreqBasis + carrNco;

            trackResults(channelNr).carrFreq(loopCnt) = carrFreq;

%% Find DLL error and update code NCO -------------------------------------
            %����λ���
            codeError = (sqrt(I_E * I_E + Q_E * Q_E) - sqrt(I_L * I_L + Q_L * Q_L)) / ...
                (sqrt(I_E * I_E + Q_E * Q_E) + sqrt(I_L * I_L + Q_L * Q_L));
            
            % Implement code loop filter and generate NCO command
            %��Ƶ��У��ֵ
            codeNco = oldCodeNco + (tau2code/tau1code) * ...
                (codeError - oldCodeError) + codeError * (PDIcode/tau1code);
            oldCodeNco   = codeNco;
            oldCodeError = codeError;
            
            % Modify code freq based on NCO command
            codeFreq = settings.codeFreqBasis - codeNco;
            
            trackResults(channelNr).codeFreq(loopCnt) = codeFreq;

%% Record various measures to show in postprocessing ----------------------
% ��¼Ҫ��postprocessing�����еĸ��ֱ���
            % Record sample number (based on 8bit samples)
            trackResults(channelNr).absoluteSample(loopCnt) = ftell(fid)/2;
%           fprintf('ftell����ֵ��%d��:A=%f\n',loopCnt,A);
            %ftell����fid�ļ���λ��ָ���λ��

            %��ֵ
            trackResults(channelNr).dllDiscr(loopCnt)       = codeError;%����λ���
            trackResults(channelNr).dllDiscrFilt(loopCnt)   = codeNco;%��Ƶ��У��ֵ
            trackResults(channelNr).pllDiscr(loopCnt)       = carrError;%�ز�Ƶ�����������ź��븴���ز��źŵ���λ��
            trackResults(channelNr).pllDiscrFilt(loopCnt)   = carrNco;%�ز�Ƶ��У��ֵ

            trackResults(channelNr).I_E(loopCnt) = I_E;
            trackResults(channelNr).I_P(loopCnt) = I_P;
            trackResults(channelNr).I_L(loopCnt) = I_L;
            trackResults(channelNr).Q_E(loopCnt) = Q_E;
            trackResults(channelNr).Q_P(loopCnt) = Q_P;
            trackResults(channelNr).Q_L(loopCnt) = Q_L;
            
%         B=rawSignal(1);
%         fprintf('��%d������B=%f\n',loopCnt,B);
        end % for loopCnt

        % If we got so far, this means that the tracking was successful
        % Now we only copy status, but it can be update by a lock detector
        % if implemented
%         trackResults(channelNr).status  = channel(channelNr).status; 
   
%             trackResults(channelNr).dllDiscr     = trackResults(channelNr).dllDiscr(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).dllDiscrFilt   = trackResults(channelNr).dllDiscrFilt(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).pllDiscr       = trackResults(channelNr).pllDiscr(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).pllDiscrFilt   = trackResults(channelNr).pllDiscrFilt(:,(settings.msToProcess+1):(2*settings.msToProcess));
% 
%             trackResults(channelNr).I_E = trackResults(channelNr).I_E(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).I_P = trackResults(channelNr).I_P(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).I_L = trackResults(channelNr).I_L(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).Q_E = trackResults(channelNr).Q_E(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).Q_P = trackResults(channelNr).Q_P(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             trackResults(channelNr).Q_L = trackResults(channelNr).Q_L(:,(settings.msToProcess+1):(2*settings.msToProcess));
%             
%              trackResults(channelNr).absoluteSample     = trackResults(channelNr).absoluteSample(:,(settings.msToProcess+1):(2*settings.msToProcess));
%               trackResults(channelNr).codeFreq     = trackResults(channelNr).codeFreq(:,(settings.msToProcess+1):(2*settings.msToProcess));
%                trackResults(channelNr).carrFreq     = trackResults(channelNr).carrFreq(:,(settings.msToProcess+1):(2*settings.msToProcess));
        
    end % if a PRN is assigned
end % for channelNr 
disp('tracking is completed');
% Close the waitbar
close(hwb)
