function [quxian]= two_nihe_huadong()
% load('trackingResults_two_5dao8_450s.mat');
% load('trackingResults_ds6_1to5_450s.mat');
% load('trackingResults_cleandystatic_1to5.mat');
% load('trackingResults_ds2_1to5.mat');
load('trackingResults_cleandyna_1to4.mat');
% load('trackingResults_ds6_1to5_450s.mat');
% %�������ڳ���
% slid_window_length = 500;

 b=500;
 cifang = 2;
 a=b-1;
 c=500;
 d=c-1;
 slid=0.9;
 time_end = 400000;

%    threshold = 1.25;%ds8
%     threshold = 1.095;%ds6
%       threshold = 1.121%ds2
%     threshold = 1.094%ds5
   threshold = 1.113 ;%cleandynamic
%    threshold = 1.124 ;%ds3
%    threshold = 1.116 ;%ds4
 index_double_curve = 1:1:b;

 for channelNr = 1:4
%          i=0;
%          cc = 0;
%          while(1)
%              i = i+1;
%              cc = cc+1;
%                 if (cc == b)
%                     data_carr_bi_noise = trackResults(channelNr).carr_bi_noise(i-a:i);
%                     p = polyfit(index_double_curve,data_carr_bi_noise,cifang);
%                     curve_carr_bi_noise = polyval(p,index_double_curve);
%                     quxian(channelNr).curve_carr_bi_noise(i-a:i)=curve_carr_bi_noise;
%                 
%                     data_noise_power = trackResults(channelNr).noise_power(i-a:i);
%                     p = polyfit(index_double_curve,data_noise_power,cifang);
%                     curve_noise_power = polyval(p,index_double_curve);
%                     quxian(channelNr).curve_noise_power(i-a:i)=curve_noise_power;
%                     cc = 0;
%                     i = (i-b*slid);
%                 end
%                 if(i == 400000)
%                     break; 
%                 end
%          end
%             [curve_up_carr_bi_noise,curve_down_carr_bi_noise]=envelope(trackResults(channelNr).carr_bi_noise(1:end),1000,'peak');
%             [curve_up_noise_power,curve_down_noise_power]=envelope(trackResults(channelNr).noise_power(1:end),1000,'peak'); 
% %    quxian(channelNr).curve_carr_bi_noise = [quxian(channelNr).curve_carr_bi_noise curve_up_carr_bi_noise];
% %    quxian(channelNr).curve_noise_power = [quxian(channelNr).curve_noise_power curve_up_noise_power];
%    quxian(channelNr).curve_carr_bi_noise = [curve_up_carr_bi_noise];
%    quxian(channelNr).curve_noise_power = [curve_up_noise_power];
   %----------------------�쳣ֵ�������ǰ�����ݣ�������׼��------------------------
length = 40000;
err_sum_curve_carr_bi_noise = 0;
err_sum_curve_noise_power = 0;
carr_bi_noise_vi(length) = 0;
carr_bi_noise_sum_vi = 0;
noise_power_vi(length) = 0;
noise_power_sum_vi = 0;
count = 0;
for i =1:time_end
    err_sum_curve_carr_bi_noise = err_sum_curve_carr_bi_noise + trackResults(channelNr).carr_bi_noise(i);
    err_sum_curve_noise_power = err_sum_curve_noise_power + trackResults(channelNr).noise_power(i);
    count = count +1 ;
    if (count==length)
        err_ave_curve_carr_bi_noise = err_sum_curve_carr_bi_noise/length;
        err_sum_curve_carr_bi_noise = 0;
        err_ave_curve_noise_power = err_sum_curve_noise_power/length;
        err_sum_curve_noise_power = 0;
        jj=1;
        for ii = (i-length+1):i
            carr_bi_noise_vi(jj) =  trackResults(channelNr).carr_bi_noise(ii) - err_ave_curve_carr_bi_noise;
            noise_power_vi(jj) =  trackResults(channelNr).noise_power(ii) - err_ave_curve_noise_power;
            jj=jj+1;
        end
        jj=1;
        for j = 1:length
            carr_bi_noise_sum_vi = carr_bi_noise_sum_vi + (carr_bi_noise_vi(j)*carr_bi_noise_vi(j));
            noise_power_sum_vi = noise_power_sum_vi + (noise_power_vi(j)*noise_power_vi(j));
        end
        carr_bi_noise_var = sqrt(carr_bi_noise_sum_vi/(length-1));
        carr_bi_noise_sum_vi = 0;
        noise_power_var = sqrt(noise_power_sum_vi/(length-1));
        noise_power_sum_vi = 0;       
        for ii = (i-length+1):i
            if(abs(carr_bi_noise_vi(jj)) > (3*carr_bi_noise_var))
                trackResults(channelNr).carr_bi_noise(ii) = err_ave_curve_carr_bi_noise;
            end
            if(abs(noise_power_vi(jj)) > (3*noise_power_var))
                trackResults(channelNr).noise_power(ii) = err_ave_curve_noise_power;
            end
            jj = jj+1;
        end
        i = (i-length*0.9+1);
        count = 0;
    end  
end
%---------------------------------�������-------------------------------------------
        %��������
         i=0;
         cc = 0;
         Lmin=500;
         L_noise=Lmin;
         sum = 0;
         j = 1;
         Lmax = 6000;
         skip_flag = 0;
         while(1)
             if(j+L_noise-1>=time_end)
                 L_noise=time_end-j;
                 skip_flag = 1;
             end
             
             if (skip_flag == 0)
                 for i=j:j+L_noise-1                                                  %�����ʼ������ϵ��
                     sum = sum + trackResults(channelNr).noise_power(i);
                 end
                    ave_noise = sum/L_noise;
                    sum = 0;
                 for i = 1:L_noise
                     sum = sum+(trackResults(channelNr).noise_power(i)-ave_noise)*(trackResults(channelNr).noise_power(i)-ave_noise);
                 end
                    var_noise = sum/L_noise;
                    coeff_var_noise_first = sqrt(var_noise)/ave_noise;
                    sum = 0;
                 while(1)                                                            %ѭ������L
                     L_noise=L_noise + (Lmin/10);
                     if(j+L_noise-1>=time_end)
                         L_noise=time_end-j;
                         skip_flag = 1;
                     end                     
                     for i=j:j+L_noise-1
                         sum = sum + trackResults(channelNr).noise_power(i);
                     end
                        ave_noise = sum/L_noise;
                        sum = 0;
                     for i = 1:L_noise
                         sum = sum+(trackResults(channelNr).noise_power(i)-ave_noise)*(trackResults(channelNr).noise_power(i)-ave_noise);
                     end
                        var_noise = sum/L_noise;
                        coeff_var_noise_later = sqrt(var_noise)/ave_noise;
                        sum = 0;
                    if(L_noise>=Lmax)
                        break;
                    end
                     if (L_noise<Lmax)
                        if(coeff_var_noise_later>=coeff_var_noise_first)
                            L_noise = L_noise - (Lmin/10);
                            break;
                        end
                     end
                     coeff_var_noise_first = coeff_var_noise_later;
                 end
             end
             
             index_double_curve = 1:1:L_noise;
             while(1)                                                           %����Ӧ���������ڼ���
                 j = j+1;
                 cc = cc+1;
                    if (cc == L_noise) 
                        data_noise_power = trackResults(channelNr).noise_power(j-L_noise+1:j);
                        p = polyfit(index_double_curve,data_noise_power,cifang);
                        curve_noise_power = polyval(p,index_double_curve);
                        quxian(channelNr).curve_noise_power(j-L_noise+1:j)=curve_noise_power;
                        cc = 0;
                        if(skip_flag == 0)
                            j = (j-L_noise*slid);    
                        end
                        skip_flag = 0;
                        L_noise = Lmin;
                        break;
                    end 
             end    
                    
             if(j >= time_end)
                 break; 
             end
        end
        
         %�����
         j=1;
         L_carr_bi_noise=Lmin;
         sum=0;
         while(1)
             if(j+L_carr_bi_noise-1>=time_end)
                 L_carr_bi_noise=time_end-j;
                 skip_flag = 1;
             end             
             
             if (skip_flag == 0)
                 for i=j:j+L_carr_bi_noise-1                                                  %�����ʼ������ϵ��
                     sum = sum + trackResults(channelNr).carr_bi_noise(i);
                 end
                    ave_carr_bi = sum/L_carr_bi_noise;
                    sum = 0;
                 for i = 1:L_carr_bi_noise
                     sum = sum+(trackResults(channelNr).carr_bi_noise(i)-ave_carr_bi)*(trackResults(channelNr).carr_bi_noise(i)-ave_carr_bi);
                 end
                    var_carr_bi_noise = sum/L_carr_bi_noise;
                    coeff_var_carr_bi_first = sqrt(var_carr_bi_noise)/ave_carr_bi;
                    sum = 0;
                 while(1)                                                            %ѭ������L
                     L_carr_bi_noise=L_carr_bi_noise + (Lmin/10);
                     if(j+L_carr_bi_noise-1>=time_end)
                         L_carr_bi_noise=time_end-j;
                         skip_flag = 1;
                     end                     
                     for i=j:j+L_carr_bi_noise-1
                         sum = sum + trackResults(channelNr).carr_bi_noise(i);
                     end
                        ave_carr_bi = sum/L_carr_bi_noise;
                        sum = 0;
                     for i = 1:L_carr_bi_noise
                         sum = sum+(trackResults(channelNr).carr_bi_noise(i)-ave_carr_bi)*(trackResults(channelNr).carr_bi_noise(i)-ave_carr_bi);
                     end
                        var_carr_bi_noise = sum/L_carr_bi_noise;
                        coeff_var_carr_bi_later = sqrt(var_carr_bi_noise)/ave_carr_bi;
                        sum = 0;
                    if(L_carr_bi_noise>=Lmax)
                        break;
                    end
                     if (L_carr_bi_noise<Lmax)
                        if(coeff_var_carr_bi_later>=coeff_var_carr_bi_first)
                            L_carr_bi_noise = L_carr_bi_noise - (Lmin/10);
                            break;
                        end
                     end
                     coeff_var_carr_bi_first = coeff_var_carr_bi_later;
                 end
             end
             
             index_double_curve = 1:1:L_carr_bi_noise;
             while(1)                                                           %����Ӧ���������ڼ���
                 j = j+1;
                 cc = cc+1;
                    if (cc == L_carr_bi_noise) 
                        data_carr_bi_noise = trackResults(channelNr).carr_bi_noise(j-L_carr_bi_noise+1:j);
                        p = polyfit(index_double_curve,data_carr_bi_noise,cifang);
                        curve_carr_bi_noise = polyval(p,index_double_curve);
                        quxian(channelNr).curve_carr_bi_noise(j-L_carr_bi_noise+1:j)=curve_carr_bi_noise;
                        cc = 0;
                        if(skip_flag == 0)
                            j = (j-L_carr_bi_noise*slid);
                        end
                        skip_flag = 0;
                        L_carr_bi_noise = Lmin;
                        break;
                    end 
             end
               if(j >= time_end)
                    break; 
               end
        end         
         
%----------------------------------�������---------------------------------------
%             [curve_up_carr_bi_noise,curve_down_carr_bi_noise]=envelope(trackResults(channelNr).carr_bi_noise(1:end),1000,'peak');
%             [curve_up_noise_power,curve_down_noise_power]=envelope(trackResults(channelNr).noise_power(1:end),1000,'peak'); 
% %    quxian(channelNr).curve_carr_bi_noise = [quxian(channelNr).curve_carr_bi_noise curve_up_carr_bi_noise];
% %    quxian(channelNr).curve_noise_power = [quxian(channelNr).curve_noise_power curve_up_noise_power];
%    quxian(channelNr).curve_carr_bi_noise = [curve_up_carr_bi_noise];
%    quxian(channelNr).curve_noise_power = [curve_up_noise_power];
% %----------------------�쳣ֵ������Ϻ�����ݣ�������׼��------------------------
% length = 12000;
% err_sum_curve_carr_bi_noise = 0;
% err_sum_curve_noise_power = 0;
% carr_bi_noise_vi(length) = 0;
% carr_bi_noise_sum_vi = 0;
% noise_power_vi(length) = 0;
% noise_power_sum_vi = 0;
% count = 0;
% for i =1:time_end
%     err_sum_curve_carr_bi_noise = err_sum_curve_carr_bi_noise + quxian(channelNr).curve_carr_bi_noise(i);
%     err_sum_curve_noise_power = err_sum_curve_noise_power + quxian(channelNr).curve_noise_power(i);
%     count = count +1 ;
%     if (count==length)
%         err_ave_curve_carr_bi_noise = err_sum_curve_carr_bi_noise/length;
%         err_sum_curve_carr_bi_noise = 0;
%         err_ave_curve_noise_power = err_sum_curve_noise_power/length;
%         err_sum_curve_noise_power = 0;
%         jj=1;
%         for ii = (i-length+1):i
%             carr_bi_noise_vi(jj) =  quxian(channelNr).curve_carr_bi_noise(ii) - err_ave_curve_carr_bi_noise;
%             noise_power_vi(jj) =  quxian(channelNr).curve_noise_power(ii) - err_ave_curve_noise_power;
%             jj=jj+1;
%         end
%         jj=1;
%         for j = 1:length
%             carr_bi_noise_sum_vi = carr_bi_noise_sum_vi + (carr_bi_noise_vi(j)*carr_bi_noise_vi(j));
%             noise_power_sum_vi = noise_power_sum_vi + (noise_power_vi(j)*noise_power_vi(j));
%         end
%         carr_bi_noise_var = sqrt(carr_bi_noise_sum_vi/(length-1));
%         carr_bi_noise_sum_vi = 0;
%         noise_power_var = sqrt(noise_power_sum_vi/(length-1));
%         noise_power_sum_vi = 0;       
%         for ii = (i-length+1):i
%             if(abs(carr_bi_noise_vi(jj)) > (3*carr_bi_noise_var))
%                 quxian(channelNr).curve_carr_bi_noise(ii) = err_ave_curve_carr_bi_noise;
%             end
%             if(abs(noise_power_vi(jj)) > (3*noise_power_var))
%                 quxian(channelNr).curve_noise_power(ii) = err_ave_curve_noise_power;
%             end
%             jj = jj+1;
%         end
%         i = (i-length*0.9+1);
%         count = 0;
%     end  
% end
   %---------------------------������� ��������-----------------------------
%     figure(channelNr);
%     subplot(2,2,1);
%     plot(trackResults(channelNr).carr_bi_noise);
%     title({['����',num2str(trackResults(channelNr).PRN),'�����ԭͼ']});
%     subplot(2,2,3);
%     plot(quxian(channelNr).curve_carr_bi_noise);%ave_noise_power
%     title({['����',num2str(trackResults(channelNr).PRN),'������������']});
%     
%     
%     subplot(2,2,2);
%     plot(trackResults(channelNr).noise_power);
%     title({['����',num2str(trackResults(channelNr).PRN),'��������ԭͼ']});
%     subplot(2,2,4);
%     plot(quxian(channelNr).curve_noise_power);%ave_carr_bi_noise
%     title({['����',num2str(trackResults(channelNr).PRN),'���������������']});
  
     %-----------------------����������ȷ���ȼ���------------------------------
   sum_noise_power = 0;
   sum_carr_bi_noise = 0;
   dd = 0;
   i=0;
                %---�ȼ�������Ӧ���ڴ�С   ��������-----
         Lmin=500;
         L_noise=Lmin;
         sum = 0;
         j = 0;
         Lmax = 6000;
         skip_flag = 0;
         all_finsh_flag = 0;
         while(1)
             if(j+L_noise-1>=time_end)
                 L_noise=time_end-j;
                 skip_flag = 1;
             end
             
             if (skip_flag == 0)
                 for i=(j+1):j+L_noise-1                                                  %�����ʼ������ϵ��
                     sum = sum + quxian(channelNr).curve_noise_power(i);
                 end
                    ave_noise = sum/L_noise;
                    sum = 0;
                 for i = 1:L_noise
                     sum = sum+(quxian(channelNr).curve_noise_power(i)-ave_noise)*(quxian(channelNr).curve_noise_power(i)-ave_noise);
                 end
                    var_noise = sum/L_noise;
                    coeff_var_noise_first = sqrt(var_noise)/ave_noise;
                    sum = 0;
                 while(1)                                                            %ѭ������L
                     L_noise=L_noise + (Lmin/10);
                     if(j+L_noise-1>=time_end)
                         L_noise=time_end-j;
                         skip_flag = 1;
                     end
                     for i=(j+1):j+L_noise-1
                         sum = sum + quxian(channelNr).curve_noise_power(i);
                     end
                        ave_noise = sum/L_noise;
                        sum = 0;
                     for i = 1:L_noise
                         sum = sum+(quxian(channelNr).curve_noise_power(i)-ave_noise)*(quxian(channelNr).curve_noise_power(i)-ave_noise);
                     end
                        var_noise = sum/L_noise;
                        coeff_var_noise_later = sqrt(var_noise)/ave_noise;
                        sum = 0;
                    if(L_noise>=Lmax)
                        break;
                    end
                     if (L_noise<Lmax)
                        if(coeff_var_noise_later>=coeff_var_noise_first)
                            L_noise = L_noise - (Lmin/10);
                            break;
                        end
                     end
                     coeff_var_noise_first = coeff_var_noise_later;
                 end
             end
             
                             

                   while(1)                                                %�������߼���һ����
                       j=j+1;
                           sum_noise_power = sum_noise_power + quxian(channelNr).curve_noise_power(j); 
                           dd = dd +1;
                       if (dd == L_noise)
                           ave_noise_power(j-L_noise+1:j) = sum_noise_power/L_noise;
                           sum_noise_power = 0;
                           dd = 0;
                           if(skip_flag == 0)
                               j = (j-L_noise*slid); 
                           end
                           L_noise = Lmin;
                           if(j >= time_end)
                                all_finsh_flag = 1;
                                break; 
                           end                           
                           break;            
                       end
                   end
               
               if(all_finsh_flag == 1)
                   break;
               end
         end
         
%          save('ave_noise_power','ave_noise_power'); 
                 %---�ȼ�������Ӧ���ڴ�С   �����-----
         j=0;
         L_carr_bi_noise=Lmin;
         sum=0;
         skip_flag = 0;
         all_finsh_flag = 0;
         while(1)
             if(j+L_carr_bi_noise-1>=time_end)
                 L_carr_bi_noise=time_end-j;
                 skip_flag = 1;
             end             
             
             if (skip_flag == 0)
                 for i=(j+1):j+L_carr_bi_noise-1                                                  %�����ʼ������ϵ��
                     sum = sum + quxian(channelNr).curve_carr_bi_noise(i);
                 end
                    ave_carr_bi = sum/L_carr_bi_noise;
                    sum = 0;
                 for i = 1:L_carr_bi_noise
                     sum = sum+(quxian(channelNr).curve_carr_bi_noise(i)-ave_carr_bi)*(quxian(channelNr).curve_carr_bi_noise(i)-ave_carr_bi);
                 end
                    var_carr_bi_noise = sum/L_carr_bi_noise;
                    coeff_var_carr_bi_first = sqrt(var_carr_bi_noise)/ave_carr_bi;
                    sum = 0;
                 while(1)                                                            %ѭ������L
                     L_carr_bi_noise=L_carr_bi_noise + (Lmin/10);
                     if(j+L_carr_bi_noise-1>=time_end)
                         L_carr_bi_noise=time_end-j;
                         skip_flag = 1;
                     end
                     for i=(j+1):j+L_carr_bi_noise-1
                         sum = sum + quxian(channelNr).curve_carr_bi_noise(i);
                     end
                        ave_carr_bi = sum/L_carr_bi_noise;
                        sum = 0;
                     for i = 1:L_carr_bi_noise
                         sum = sum+(quxian(channelNr).curve_carr_bi_noise(i)-ave_carr_bi)*(quxian(channelNr).curve_carr_bi_noise(i)-ave_carr_bi);
                     end
                        var_carr_bi_noise = sum/L_carr_bi_noise;
                        coeff_var_carr_bi_later = sqrt(var_carr_bi_noise)/ave_carr_bi;
                        sum = 0;
                    if(L_carr_bi_noise>=Lmax)
                        break;
                    end
                     if (L_carr_bi_noise<Lmax)
                        if(coeff_var_carr_bi_later>=coeff_var_carr_bi_first)
                            L_carr_bi_noise = L_carr_bi_noise - (Lmin/10);
                            break;
                        end
                     end
                     coeff_var_carr_bi_first = coeff_var_carr_bi_later;
                 end
             end
             
               

                   while(1)                                                %�������߼���һ����
                       j=j+1;                       
                           sum_carr_bi_noise = sum_carr_bi_noise + quxian(channelNr).curve_carr_bi_noise(j); 
                           dd = dd +1;
                       if (dd == L_carr_bi_noise)
                           ave_carr_bi_noise(j-L_carr_bi_noise+1:j) = sum_carr_bi_noise/L_carr_bi_noise;
                           sum_carr_bi_noise = 0;
                           dd = 0;
                           if(skip_flag == 0)
                               j = (j-L_carr_bi_noise*slid); 
                           end
                           L_carr_bi_noise = Lmin;
                           if(j >= time_end)
                                all_finsh_flag = 1;
                                break; 
                           end                           
                           break;
                       end
                   end
              
               if(all_finsh_flag == 1)
                   break;
               end
         end
%         save('ave_carr_bi_noise','ave_carr_bi_noise'); 
    %--------------�������----------------------
   %----------------��ʼ���-------------------------
   dd = 0;
   noise_power(1:Lmin) = 0;
   carr_bi_noise(1:Lmin) = 0;
   i=Lmin;
   while(1)
       i = i+1;
       dd = dd +1;
        if (dd == Lmin)
           noise_power(i-d:i) = threshold*ave_noise_power(i-d:i) - (1/threshold)*ave_noise_power(1:Lmin) ;
           carr_bi_noise(i-d:i) = (1/threshold)*ave_carr_bi_noise(i-d:i)-threshold*ave_carr_bi_noise(1:Lmin);
           dd = 0;
           i = (i-Lmin*slid);
        end
        if(i == time_end)
            break; 
       end
   end
   dd = 0;
   i = 0;
   while(1)
       i=i+1;
       dd = dd +1 ;
       if (dd == Lmin)
           detect(channelNr,i-d:i) = noise_power(i-d:i).*carr_bi_noise(i-d:i);
           dd = 0;
           i = (i-Lmin*slid);           
       end
       if(i == time_end)
            break; 
       end
   end
   
 %----------------����ϵ��-----------------------------  
%    %���ֵ
%    window = Lmin;
%    leijia_noise = 0;
%    leijia_carr_bi = 0;
%    gg = 0;
%    load('fangcha_before_noise.mat');
%    load('fangcha_before_carr_bi.mat');
%    load('piancha_before_noise.mat');
%    load('piancha_before_carr_bi.mat');
%    load('xinxishang_before_noise.mat');
%    load('xinxishang_before_carr_bi.mat');
%    load('bianyixishu_before_noise.mat');
%    load('bianyixishu_before_carr_bi.mat');
%    for i = 1:time_end           %��ֵ�������
%        gg = gg + 1;
%        leijia_noise = leijia_noise + ave_noise_power(i);
%        leijia_carr_bi = leijia_carr_bi + ave_carr_bi_noise(i);
%         if(gg == window)
%             pinjun_noise(i-window+1:i) = leijia_noise/window;
%             pinjun_carr_bi(i-window+1:i) = leijia_carr_bi/window;
%             leijia_noise = 0;
%             leijia_carr_bi = 0;
%             gg = 0;
%         end
%    end
%    gg = 0;
%    leicheng_noise = 0;
%    leicheng_carr_bi = 0;
%     for i = 1:time_end                                 %�������
%         gg = gg + 1;
%         leicheng_noise = leicheng_noise + (ave_noise_power(i)-pinjun_noise(i))*(ave_noise_power(i)-pinjun_noise(i));
%         leicheng_carr_bi = leicheng_carr_bi + (ave_carr_bi_noise(i)-pinjun_carr_bi(i))*(ave_carr_bi_noise(i)-pinjun_carr_bi(i));
%         if(gg == window)
%             fangcha_noise(i-window+1:i) = leicheng_noise/window;
%             fangcha_carr_bi(i-window+1:i) = leicheng_carr_bi/window;
%             leicheng_noise =  0;
%             leicheng_carr_bi = 0;
%             gg = 0;
%         end
%     end
%     save('fangcha_noise','fangcha_noise');
%     save('fangcha_carr_bi','fangcha_carr_bi');    
%     figure(1);
%     plot(1:time_end,fangcha_noise(1:time_end),'r');
%     hold on;
%     plot(1:time_end,fangcha_before_noise(1:time_end),'g');
%     title('����-��������');
%     figure(2);
%     plot(1:time_end,fangcha_carr_bi(1:time_end),'r');
%     hold on;
%     plot(1:time_end,fangcha_before_carr_bi(1:time_end),'g');
%     title('����-�����');
%    gg = 0;                                                                          %ƫ�
%     piancha_temp_noise(1:window) = 0;                                                   
%     piancha_temp_carr_bi(1:window) = 0;
%    for i = 1:time_end
%         gg = gg + 1;
%         if(gg == window)
%             piancha_temp_noise(1:window) = abs( (i-window+1:i) - pinjun_noise(i-window+1:i) );
%             piancha_temp_carr_bi(1:window) = abs( (i-window+1:i) - pinjun_noise(i-window+1:i) );
%             piancha_noise(i-window+1:i) = piancha_temp_noise(1:window)./sqrt(fangcha_noise(i-window+1:i));
%             piancha_carr_bi(i-window+1:i) = piancha_temp_carr_bi(1:window)./sqrt(fangcha_carr_bi(i-window+1:i));
%             gg = 0;
%         end
%    end
% %     [f_piancha_noise , xi_piancha_noise] = ksdensity(piancha_noise);
% %     subplot(2,1,1);
% %     plot(xi_piancha_noise,f_piancha_noise);
% %     [f_piancha_noise_before , xi_piancha_noise_before] = ksdensity(piancha_before_noise);
% %     subplot(2,1,2);
% %     plot(xi_piancha_noise_before,f_piancha_noise_before);    
%     save('piancha_noise','piancha_noise');
%     save('piancha_carr_bi','piancha_carr_bi');
%     
%     
%     figure(3);
%     plot(1:time_end,piancha_noise(1:time_end),'r');
%     hold on;
%     plot(1:time_end,piancha_before_noise(1:time_end),'g');
%     title('ƫ��-��������');
%     figure(4);
%     plot(1:time_end,piancha_carr_bi(1:time_end),'r');
%     hold on;
%     plot(1:time_end,piancha_before_carr_bi(1:time_end),'g');
%     title('ƫ��-�����');
%    
%     
%     
%     gg = 0;                                                                %��Ϣ�ط�
%     qiuhe_noise = 0;
%     qiuhe_carr_bi = 0;
%    for i = 1:time_end
%         gg = gg + 1;
%         qiuhe_noise = qiuhe_noise + ave_noise_power(i);
%         qiuhe_carr_bi = qiuhe_carr_bi + ave_carr_bi_noise(i);
%         if(gg == window)
%             pi_noise(i-window+1:i) = ave_noise_power(i-window+1:i)/qiuhe_noise;
%             pi_carr_bi(i-window+1:i) = ave_carr_bi_noise(i-window+1:i)/qiuhe_carr_bi;
%             qiuhe_noise = 0;
%             qiuhe_carr_bi = 0;
%             gg = 0;
%         end
%    end
%    gg = 0;
%    Hs_noise = 0;
%    Hs_carr_bi = 0;
%    for i = 1:time_end
%        gg = gg + 1;
%        Hs_noise = Hs_noise + pi_noise(i)*log2(pi_noise(i));
%        Hs_carr_bi = Hs_carr_bi + pi_carr_bi(i)*log2(pi_carr_bi(i));
%        if(gg == window)
%            xinxishang_noise(i-window+1:i) = (-1*Hs_noise);
%            xinxishang_carr_bi(i-window+1:i) = (-1*Hs_carr_bi);
%            Hs_noise = 0;
%            Hs_carr_bi = 0;
%            gg = 0;
%        end
%    end
%     save('xinxishang_noise','xinxishang_noise');
%     save('xinxishang_carr_bi','xinxishang_carr_bi');
%     figure(5);
%     plot(1:time_end,xinxishang_noise(1:time_end),'r');
%     hold on;
%     plot(1:time_end,xinxishang_before_noise(1:time_end),'g');
%     title('��Ϣ��-��������');
%     figure(6);
%     plot(1:time_end,xinxishang_carr_bi(1:time_end),'r');
%     hold on;
%     plot(1:time_end,xinxishang_before_carr_bi(1:time_end),'g');
%     title('��Ϣ��-�����');
%     gg = 0;                                                    %����ϵ����
%    for i = 1:time_end
%        gg = gg + 1;
%        if(gg == window)
%            bianyixishu_noise(i-window+1:i) = sqrt(fangcha_noise(i-window+1:i))./pinjun_noise(i-window+1:i);
%            bianyixishu_carr_bi(i-window+1:i) = sqrt(fangcha_carr_bi(i-window+1:i))./pinjun_carr_bi(i-window+1:i);
%            gg = 0;
%        end
%    end
%     save('bianyixishu_noise','bianyixishu_noise');
%     save('bianyixishu_carr_bi','bianyixishu_carr_bi');   
%     figure(7);
%     plot(1:time_end,bianyixishu_noise(1:time_end),'r');
%     hold on;
%     plot(1:time_end,bianyixishu_before_noise(1:time_end),'g');
%     title('����ϵ��-��������');
%     figure(8);
%     plot(1:time_end,bianyixishu_carr_bi(1:time_end),'r');
%     hold on;
%     plot(1:time_end,bianyixishu_before_carr_bi(1:time_end),'g');
%    title('����ϵ��-�����');
%    AAA = 1;
   %---------------------------------�������----------------------------------
%             %�������
%    while(1)
%        i=i+1;
%            sum_noise_power = sum_noise_power + quxian(channelNr).curve_noise_power(i);
%            sum_carr_bi_noise = sum_carr_bi_noise + quxian(channelNr).curve_carr_bi_noise(i);  
%            dd = dd +1;
%        if (dd == c)
%            ave_noise_power(i-d:i) = sum_noise_power/6000;
%            ave_carr_bi_noise(i-d:i) = sum_carr_bi_noise/6000;
%            sum_noise_power = 0;
%            sum_carr_bi_noise = 0;
%            dd = 0;
%            i = (i-c*slid); 
%        end
%        if(i == time_end)
%             break; 
%        end
%    end
%    dd = 0;
%    noise_power(1:c) = 0;
%    carr_bi_noise(1:c) = 0;
%    i=c;
%    while(1)
%        i = i+1;
%        dd = dd +1;
%         if (dd == c)
%            noise_power(i-d:i) = threshold*ave_noise_power(i-d:i) - (1/threshold)*ave_noise_power(1:c) ;
%            carr_bi_noise(i-d:i) = (1/threshold)*ave_carr_bi_noise(i-d:i)-threshold*ave_carr_bi_noise(1:c);
%            dd = 0;
%            i = (i-c*slid);
%         end
%         if(i == time_end)
%             break; 
%        end
%    end
%    dd =0 ;
%    i=0;
%    while(1)
%        i=i+1;
%        dd = dd +1 ;
%        if (dd == c)
%            detect(i-d:i) = noise_power(i-d:i).*carr_bi_noise(i-d:i);
%            dd = 0;
%            i = (i-c*slid);           
%        end
%        if(i == time_end)
%             break; 
%        end
%    end

    %-----------------------ԭʼ����------------------------------
%    sum_noise_power = 0;
%    sum_carr_bi_noise = 0;
%    threshold = 1.25;
%    dd = 0;
%    i=0;
%    while(1)
%        i=i+1;
%            sum_noise_power = sum_noise_power + quxian(channelNr).curve_noise_power(i);
%            sum_carr_bi_noise = sum_carr_bi_noise + quxian(channelNr).curve_carr_bi_noise(i);  
%            dd = dd +1;
%        if (dd == c)
%            ave_noise_power(i-d:i) = sum_noise_power/6000;
%            ave_carr_bi_noise(i-d:i) = sum_carr_bi_noise/6000;
%            sum_noise_power = 0;
%            sum_carr_bi_noise = 0;
%            dd = 0;
%            i = (i-c*slid); 
%        end
%        if(i == 350000)
%             break; 
%        end      
%    end
%    dd = 0;
%    noise_power(1:c) = 0;
%    carr_bi_noise(1:c) = 0;
%    i=c;
%    while(1)
%        i = i+1;
%        dd = dd +1;
%         if (dd == c)
%            noise_power(i-d:i) = ave_noise_power(i-d:i) - ave_noise_power(1:c) ;
%            carr_bi_noise(i-d:i) = ave_carr_bi_noise(i-d:i)-ave_carr_bi_noise(1:c);
%            dd = 0;
%            i = (i-c*slid);
%         end
%        if(i == 350000)
%             break; 
%        end
%    end
%    dd =0 ;
%    i=0;
%    while(1)
%        i=i+1;
%        dd = dd +1 ;
%        if (dd == c)
%            detect(i-d:i) = noise_power(i-d:i).*carr_bi_noise(i-d:i);
%            dd = 0;
%            i = (i-c*slid);           
%        end
%        if(i == 350000)
%             break; 
%        end
%    end
  %-----------------------------------------------------------------------------
%     figure(channelNr);
%     subplot(3,1,1);
%     plot(trackResults(channelNr).carr_bi_noise);
%     title({['�����',num2str(channelNr),'ԭͼ']});
%     subplot(3,1,1);
%     plot(noise_power);%ave_noise_power
%     title({['�����',num2str(channelNr),'�������']});
%     subplot(3,1,2);
%     plot(carr_bi_noise);%ave_carr_bi_noise
%     title({['��������',num2str(channelNr),'�������']});
%          subplot(1,1,1);

% for i = 1:350000
% if (detect(i)>=0)
%     plot(i,detect(i),'--g');
%     hold on;
% end
% if (detect(i)<=0)
%     plot(i,detect(i),'m');
%     hold on;
% end
% end
%     plot(detect);%ave_carr_bi_noise
%     if()
%     title({['���',num2str(channelNr),'�������']});
%     for i = 1:250000
%             if (mod(i,b)==0)
%                 data_carr_bi_noise = trackResults(channelNr).carr_bi_noise(i-a:i);
%                 p = polyfit(index_double_curve,data_carr_bi_noise,cifang);
%                 curve_carr_bi_noise = polyval(p,index_double_curve);
%                 quxian(channelNr).curve_carr_bi_noise(i-a:i)=curve_carr_bi_noise;
%                 
%                 data_noise_power = trackResults(channelNr).noise_power(i-a:i);
%                 p = polyfit(index_double_curve,data_noise_power,cifang);
%                 curve_noise_power = polyval(p,index_double_curve);
%                 quxian(channelNr).curve_noise_power(i-a:i)=curve_noise_power;
%             end
%     end
%     [curve_up_carr_bi_noise,curve_down_carr_bi_noise]=envelope(trackResults(channelNr).carr_bi_noise,1000,'peak');
%     figure(channelNr);
%     subplot(3,2,1);
%         plot(trackResults(channelNr).carr_bi_noise);
%     title({['�����',num2str(channelNr),'ԭͼ']});
% %     t=1:250000;
% %     hold on;
% %     plot(t,curve_up_carr_bi_noise,'-',t,curve_down_carr_bi_noise,'--');
% %     hold off;
%     subplot(3,2,3);
%     plot(quxian(channelNr).curve_carr_bi_noise);
%     title({['�����',num2str(channelNr),'�������']});
%      subplot(3,2,4);
%     plot(quxian(channelNr).curve_noise_power);
%     title({['��������',num2str(channelNr),'�������']});
%     
%     [curve_up_noise_power,curve_down_noise_power]=envelope(trackResults(channelNr).noise_power,1000,'peak'); 
%     [curve_up_carr_bi_noise,curve_down_carr_bi_noise]=envelope(trackResults(channelNr).carr_bi_noise,1000,'peak');
    
%         for i = 1:250000
%             if (mod(i,1000)==0)
%                 data_carr_bi_noise = curve_carr_bi_noise(i-999:i);
%                 p = polyfit(index_double_curve,data_carr_bi_noise,2);
%                 baoluozhuannihe_carr_bi_noise = polyval(p,index_double_curve);
%                 quxian(channelNr).baoluozhuannihe_carr_bi_noise(i-999:i)=baoluozhuannihe_carr_bi_noise;
%             end
%         end
        
%     subplot(1,1,1);
%         plot(trackResults(channelNr).noise_power);
%     title({['��������',num2str(channelNr),'ԭͼ']});
%     hold on;
%     plot(t,curve_up_noise_power,'-',t,curve_down_carr_bi_noise,'--');
%     hold off;
%     subplot(3,2,5);
%     plot(curve_up_carr_bi_noise);
%     title({['�����',num2str(channelNr),'����']});
%     subplot(3,2,6);
%     plot(curve_up_noise_power);
%     title({['��������',num2str(channelNr),'����']});
%  end
%     index_double_curve = 1:1:110000;
%     
%                 data_carr_bi_noise = quxian(channelNr).curve_carr_bi_noise(1:110000);
%                 curve_carr_bi_noise = polyfit(index_double_curve,data_carr_bi_noise,3);
%                 curve_carr_bi_noise = polyval(curve_carr_bi_noise,index_double_curve);
%                 quxian(channelNr).curve_carr_bi_noise(1:110000)=curve_carr_bi_noise;
%         index_double_curve = 110001:1:250000;
%     
%                 data_carr_bi_noise = quxian(channelNr).curve_carr_bi_noise(110001:250000);
%                 curve_carr_bi_noise = polyfit(index_double_curve,data_carr_bi_noise,2);
%                 curve_carr_bi_noise = polyval(curve_carr_bi_noise,index_double_curve);
%                 quxian(channelNr).curve_carr_bi_noise(110001:250000)=curve_carr_bi_noise;
                
%      [quxian(channelNr).curve_carr_bi_noise,~]=envelope(trackResults(channelNr).noise_power,10000,'analytic'); 
%      subplot(2,1,2);
%      plot(quxian(channelNr).curve_carr_bi_noise_2);
%----------------------------------��-----------------------------------------------
% figure(channelNr);
%     for i = 1:19:345000
%         if (detect(i) ==0 ) %��ɫ�����ο�
%             plot(i:(i+19),detect(i:i+19),'r');
%             hold on;
%         end
%         if (detect(i)>0)      %��ɫ���ߴ�����ƭ
%             plot(i:(i+19),detect(i:i+19),'g');
%             hold on;
%         end
%         if (detect(i)<0)%��ɫ����δ��⵽��ƭ
%             plot(i:(i+19),detect(i:i+19),'b');
%             hold on;
%         end
%     end
    
 end
     save('detect_cleanDynamic_1to5','detect');
% for i = 1:20:350000
%     if (detect(i)==0)
%     plot(i:(i+20),detect(i:i+20),'r');
%     hold on;
% end
% if (detect(i)>0)
%     plot(i:(i+20),detect(i:i+20),'--g');
%     hold on;
% end
% if (detect(i)<0)
%     plot(i:(i+20),detect(i:i+20),'m');
%     hold on;
% end
% end
%                 data_noise_power = trackResults(channelNr).noise_power(i-999:i);
%                 curve_noise_power = polyfit(index_double_curve,data_noise_power,2);
%                 syms x2
%                 y2 = curve_noise_power(1)*x2^2+curve_noise_power(2)*x2+curve_noise_power(3);
%                 dy2 = diff(y2,x2);
%                 for i = (i-999):i
%                     x2 = i;
%                     k2 = eval(dy2);
%                     trackResults(channelNr).dy_noise_power(i)=k2;
%                 end
%                 curve_carr_bi_noise = polyfit(index_double_curve,data_carr_bi_noise,2);
%                 syms x1
%                 y1 = curve_carr_bi_noise(1)*x1^2+curve_carr_bi_noise(2)*x1+curve_carr_bi_noise(3);
%                 dy1 = diff(y1,x1);
%                 for i = (i-999):i
%                    x1 = i;
%                    k1 = eval(dy1);
%                 quxian(channelNr).dy_carr_bi_noise(i)=k1;
%                 my_detect = trackResults(channelNr).dy_noise_power(i)./k1;
%                 if (my_detect>0)
%                     my_detect=1;
%                 end
%                 if (my_detect<0)
%                    my_detect=-1; 
%                 end    
%                 trackResults(channelNr).my_detect(i)=my_detect;                
%                 end
%                 curve_carr_bi_noise = polyval(curve_carr_bi_noise,index_double_curve);
% %                 curve_noise_power = polyval(curve_noise_power,index_double_curve);
% %                 my_detect = k1./k2;
%   
%             quxian(channelNr).curve_carr_bi_noise(i-999:i)=curve_carr_bi_noise;
% %             trackResults(channelNr).curve_noise_power(i-999:i)=curve_noise_power;
%             
%             end
%     end
    