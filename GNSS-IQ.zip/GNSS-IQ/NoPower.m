function [NoPowerResults]=NoPower(channelList,settings)
global channel
for channelNr = channelList
if (settings.fileType==1)
    dataAdaptCoeff=1;
else
    dataAdaptCoeff=2;
end
[fid, message] = fopen(settings.fileName, 'rb');
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (fid > 0)
      fseek(fid, settings.fileType*dataAdaptCoeff*settings.skipNumberOfSamples, 'bof');
               samplesPerCode = round(settings.realSamplingFreq / ...
            (settings.codeFreqBasis / settings.codeLength));
        for j=1:10
     
        
        DataForCNo=fread(fid, ...
            dataAdaptCoeff*(settings.acquisition.cohCodePeriods*settings.acquisition.nonCohSums+1)*samplesPerCode*6/27, ...
            settings.dataType)';
        ftell(fid)
         if (dataAdaptCoeff==2)
            Data1=DataForCNo(1:2:end);
            Data2=DataForCNo(2:2:end);
            Data=Data1 + 1i .* Data2;
         end
       acqResults=acquisitionNo(Data,settings,channel);
       NoPowerResults(channelNr).NoisePower(j)=acqResults.NoPower(1,channel(channelNr).PRN);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        else
    % Error while opening the data file.
    error('Unable to read file %s: %s.', settings.fileName, message);
end % if (fid > 0)
end
end