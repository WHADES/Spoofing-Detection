% routine to read in binary data TEXBAT scenario 3, Logan Scott
function samples=read_ds3(duration,start_time,texbat)
sample_rate=25000000;%Hz
number_samples=ceil(duration*sample_rate);% number of samples to return
count=2*number_samples;%number of values to read (I & Q are interleaved)
point_to_begin=2*ceil(start_time*sample_rate)*2;%pointer to first value x2 for
bytes
if texbat~=3;error('Only scenario 3 at this point');end;
fid=fopen('g:/ds3/ds3.bin','r'); % open the file
fseek(fid, point_to_begin, 'bof');% position the start
s=fread(fid,count,'int16')';% read in Is and Qs
fclose(fid);
samples=s(1:2:count-1)+j*s(2:2:count); % Convert and return complex form
