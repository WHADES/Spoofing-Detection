function acqResults = acquisition(longSignal, settings)
%Function performs cold start acquisition on the collected "data". It
%searches for GPS signals of all satellites, which are listed in field
%"acqSatelliteList" in the settings structure. Function saves code phase
%and frequency of the detected signals in the "acqResults" structure.
%
%acqResults = acquisition(longSignal, settings)
%
%   Inputs:
%       longSignal    - 11 ms of raw signal from the front-end 
%       settings      - Receiver settings. Provides information about
%                       sampling and intermediate frequencies and other
%                       parameters including the list of the satellites to
%                       be acquired.
%   Outputs: 
%       acqResults    - Function saves code phases and frequencies of the 
%                       detected signals in the "acqResults" structure. The
%                       field "carrFreq" is set to 0 if the signal is not
%                       detected for the given PRN number. 
 
%--------------------------------------------------------------------------
%                           SoftGNSS v3.0
% 
% Copyright (C) Darius Plausinaitis and Dennis M. Akos
% Written by Darius Plausinaitis and Dennis M. Akos
% Based on Peter Rinder and Nicolaj Bertelsen
%--------------------------------------------------------------------------
%This program is free software; you can redistribute it and/or
%modify it under the terms of the GNU General Public License
%as published by the Free Software Foundation; either version 2
%of the License, or (at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program; if not, write to the Free Software
%Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
%USA.
%--------------------------------------------------------------------------

%CVS record:
%$Id: acquisition.m,v 1.1.2.12 2006/08/14 12:08:03 dpl Exp $

%% Initialization =========================================================

% Find number of samples per spreading code
samplesPerCode = round(settings.samplingFreq / ...
                        (settings.codeFreqBasis / settings.codeLength));
% count = 2*samplesPerCode;
% Create two 1msec vectors of data to correlate with and one with zero DC
signal1 = longSignal(1 : samplesPerCode);
signal2 = longSignal(samplesPerCode+1 : 2*samplesPerCode);


% longSignal = longSignal(1:2:11*count-1)+j*longSignal(2:2:11*count);
% signal10ms = longSignal(1:10*samplesPerCode); 

% Find sampling period
%��������
ts = 1 / settings.samplingFreq;

% Find phase points of the local carrier wave 
%�ҵ������ز��ϵ���λ��
%��λ������w*t��w=2��f
%phasePoints=(0-һ��C/A���������������*2��*��������
phasePoints = (0 : (samplesPerCode-1)) * 2 * pi * ts;

% Number of the frequency bins for the given acquisition band (500Hz steps)
%�����������+1
numberOfFrqBins = round(settings.acqSearchBand * 2) + 1;

% Generate all C/A codes and sample them according to the sampling freq.
%C/A�������
caCodesTable = makeCaTable(settings);


%--- Initialize arrays to speed up the code -------------------------------
% Search results of all frequency bins and code shifts (for one satellite)
%����һ������ÿ��������Ƶ�ƺ�����λ�ƶ�����������Ž���
results     = zeros(numberOfFrqBins, samplesPerCode);

% Carrier frequencies of the frequency bins
%����һ�������ز�������
frqBins     = zeros(1, numberOfFrqBins);


%--- Initialize acqResults ------------------------------------------------
% Carrier frequencies of detected signals
acqResults.carrFreq     = zeros(1, 32);
% C/A code phases of detected signals
acqResults.codePhase    = zeros(1, 32);
% Correlation peak ratios of the detected signals
acqResults.peakMetric   = zeros(1, 32);

fprintf('(');

% Perform search for all listed PRN numbers ...
for PRN = settings.acqSatelliteList   %settings.acqSatelliteList

%% Correlate signals ======================================================   
    %--- Perform DFT of C/A code ------------------------------------------
    %��C/A����DFTcaCodesTable(PRN, :)��ÿһ�е�ֵѡ����
    %conj��һ��������ʱ��conj����conj(z)Ԫ�صĹ����
    %fft������������DFT����ɢ����Ҷ�仯
    caCodeFreqDom = conj(fft(caCodesTable(PRN, :)));%��أ������ź����źźͱ����źŵĹ������

    %--- Make the correlation for whole frequency band (for all freq. bins)
    %---������Ƶ�ʷ�Χ������ؼ��
    for frqBinIndex = 1:numberOfFrqBins

        %--- Generate carrier wave frequency grid (0.5kHz step) -----------
        frqBins(frqBinIndex) = settings.IF - ...
                               (settings.acqSearchBand/2) * 1000 + ...
                               0.5e3* (frqBinIndex - 1);

        %--- Generate local sine and cosine -------------------------------
        %�ز�Ƶ��
%         sinCarr = sin(frqBins(frqBinIndex) * phasePoints);
%         cosCarr = cos(frqBins(frqBinIndex) * phasePoints);
        
        sigCarr     = exp(1i*frqBins(frqBinIndex)*phasePoints);%e^(ix)=cosx+isinx
        %--- "Remove carrier" from the signal -----------------------------
%         I1      = sinCarr .* signal1;
%         Q1      = cosCarr .* signal1;
%         I2      = sinCarr .* signal2;
%         Q2      = cosCarr .* signal2;
        
        sigCarrIQ1   = sigCarr .* signal1;
%         sigCarrIQ2   = sigCarr .* signal2;
%         I1      = signal1(1:2:count-1);
%         Q1      = signal1(2:2:count);
%         I2      = signal2(1:2:count-1);
%         Q2      = signal2(2:2:count);
        %--- Convert the baseband signal to frequency domain --------------
        %�������ź�ת����Ƶ��
%         IQfreqDom1 = fft(I1 + j*Q1);
%         IQfreqDom2 = fft(I2 + j*Q2);
        
        IQfreqDom1 = fft(sigCarrIQ1);
%         IQfreqDom2 = fft(sigCarrIQ2);
        %--- Multiplication in the frequency domain (correlation in time
        %domain)
        %����أ�Ƶ����ˣ�ʱ����أ�
        convCodeIQ1 = IQfreqDom1 .* caCodeFreqDom;
%         convCodeIQ2 = IQfreqDom2 .* caCodeFreqDom;

        %--- Perform inverse DFT and store correlation results ------------
        acqRes1 = abs(ifft(convCodeIQ1)) .^ 2;
%         acqRes2 = abs(ifft(convCodeIQ2)) .^ 2;
        
        %--- Check which msec had the greater power and save that, will
        %"blend" 1st and 2nd msec but will correct data bit issues
        %����ĸ�������и���Ĺ��ʲ����棬������ϡ���һ����͵ڶ����룬������������λ����
%         if (max(acqRes1) > max(acqRes2))
%             results(frqBinIndex, :) = acqRes1;
%         else
%             results(frqBinIndex, :) = acqRes2;
%         end
         results(frqBinIndex, :) = acqRes1;
    end % frqBinIndex = 1:numberOfFrqBins

%% Look for correlation peaks in the results ==============================
    % Find the highest peak and compare it to the second highest peak
    % The second peak is chosen not closer than 1 chip to the highest peak
    %ѡ��ĵڶ�����ֵ����߷�ֵ�ľ��벻С��1����Ƭ
    %--- Find the correlation peak and the carrier frequency --------------
    %max��a,[],2���õ�a������ÿ�е����ֵ
    %frequencyBinIndexs�Ƿ��ص��������˴�ΪƵ������ֵ
    [peakSize frequencyBinIndex] = max(max(results, [], 2));


    %--- Find code phase of the same correlation peak ---------------------
    %codephase�Ƿ��ص��������˴�Ϊ����λ����ֵ
    [peakSize codePhase] = max(max(results));

    %--- Find 1 chip wide C/A code phase exclude range around the peak ----
    %�ҵ�1��оƬ����C / A����λ���ų���ֵ�����ķ�Χ
    samplesPerCodeChip   = round(settings.samplingFreq / settings.codeFreqBasis);%һ����Ƭ�м���������
    excludeRangeIndex1 = codePhase - samplesPerCodeChip;%ǰһ������λ���������ʾ��
    excludeRangeIndex2 = codePhase + samplesPerCodeChip;%��һ������λ���������ʾ��

    %--- Correct C/A code phase exclude range if the range includes array
    %boundaries
    if excludeRangeIndex1 < 2
        codePhaseRange = excludeRangeIndex2 : ...
                         (samplesPerCode + excludeRangeIndex1);
                         
    elseif excludeRangeIndex2 >= samplesPerCode
        codePhaseRange = (excludeRangeIndex2 - samplesPerCode) : ...
                         excludeRangeIndex1;
    else
        codePhaseRange = [1:excludeRangeIndex1, ...
                          excludeRangeIndex2 : samplesPerCode];%ȥ�������м�������Ƭ����
    end

    %--- Find the second highest correlation peak in the same freq. bin ---
%     ����ͬ��Ƶ�����ҵ��ڶ��ߵ���ط�
    secondPeakSize = max(results(frequencyBinIndex, codePhaseRange));

    %--- Store result -----------------------------------------------------
    acqResults.peakMetric(PRN) = peakSize/secondPeakSize;
    %acqResults.peakMetric
    % If the result is above threshold, then there is a signal ...
    if (peakSize/secondPeakSize) > settings.acqThreshold

%% Fine resolution frequency search =======================================
% %         ��ϸ�ֱ��ʵ�Ƶ������
% %         --- Indicate PRN number of the detected signal -------------------
%         fprintf('%02d ', PRN);
%         
%         %--- Generate 10msec long C/A codes sequence for given PRN --------
%         caCode = generateCAcode(PRN);
%         caCode = caCode+1i*0;
%         codeValueIndex = floor((ts * (1:10*samplesPerCode)) / ...
%                                (1/settings.codeFreqBasis));
%                            
%         longCaCode = caCode((rem(codeValueIndex, 1023) + 1));
% %         longCaCode2 = conj(fft(caCode((rem(codeValueIndex, 1023) + 1))));
% %         --- Remove C/A code modulation from the original signal ----------
% %         (Using detected C/A code phase)
% %         ��ԭʼ�ź���ɾ��C / A�������
% % ��ʹ�ü�⵽��C / A����׶Σ�
%         xCarrier = ...
%             longSignal(codePhase:(codePhase + 10*samplesPerCode-1)) ...
%             .* longCaCode;          %ʱ����� ��Ƶ���������
% %     --- Find the next highest power of two and increase by 8x --------
% %         �ҵ�2����һ������ݲ�����8��    
%         fftNumPts = 16*(2^(nextpow2(length(xCarrier))));
%         
% %         longSignal2 = fft(longSignal(codePhase:(codePhase + 10*samplesPerCode-1)));
% %         xCarrier = conv(longSignal2,longCaCode2);
% %         xCarrier = ifft(xCarrier,fftNumPts);
%         %--- Find the next highest power of two and increase by 8x --------
% %         �ҵ�2����һ������ݲ�����8��
%         fftNumPts = 16*(2^(nextpow2(length(xCarrier))));
%         
% %         --- Compute the magnitude of the FFT, find maximum and the
% %         associated carrier frequency 
% %         ����FFT�ķ��ȣ��ҵ����ֵ����ص��ز�Ƶ��
%         fftxc = abs(fft(xCarrier, fftNumPts)); 
%         
%         uniqFftPts = ceil((fftNumPts + 1) / 2);
%         [fftMax, fftMaxIndex] = max(fftxc(5 : uniqFftPts-5));
%         
%         fftFreqBins = (0 : uniqFftPts-1) * settings.samplingFreq/fftNumPts;
% %         maxpeakSize = peakSize;
% %         maxdoop     = frqBins(frequencyBinIndex);
% %         freqdopp = frqBins(frequencyBinIndex)-20:1:frqBins(frequencyBinIndex)+20;
% %         findpeak    = max(results);
% %         for doppindex = 1:length(freqdopp)
% %             if (findpeak > maxpeakSize)
% %                 maxdoop = freqdopp(doppindex);
% %                 maxpeakSize = findpeak;
% %             end
% %         end

%-----------------------------------------------------------------------
        fprintf('%02d ', PRN);
        caCode = generateCAcode(PRN);
        codeValueIndex = floor((ts * (1:samplesPerCode)) / ...
                               (1/settings.codeFreqBasis));                
        longCaCode = caCode((rem(codeValueIndex, 1023) + 1));
        
         xCarrier = ...
            longSignal(codePhase:(codePhase + samplesPerCode-1)) ...
            .* longCaCode;
        
        freqency = frqBins(frequencyBinIndex);
%         if (freqency<=0)
%             freqency = -freqency;
%         end
        for i = 1:281
        freqencyDop = freqency - 7000 + 50*(i-1);
        sigCarr     = exp(1i*freqencyDop*phasePoints);
        sigCarrFreqDom = conj(fft(sigCarr));
        xCarrierDom1 = fft(xCarrier);
        convCodeSig = xCarrierDom1.*sigCarrFreqDom;
        acqDopRes1 = abs(ifft(convCodeSig));
        resultsDop(i, :) = acqDopRes1;
        peakSizeDop(i)=max(acqDopRes1);
        end
        [a i] = max(max(resultsDop, [], 2));%i������aֵ
        x(1)= freqency - 7000 + 50*(i-2);
        x(2)= freqency - 7000 + 50*(i-1);
        x(3)= freqency - 7000 + 50*(i);
        y(1)= peakSizeDop(i-1);
        y(2)= peakSizeDop(i);
        y(3)= peakSizeDop(i+1);
        
        %�ⷽ����
        A = [x(1)^2,x(1),1;x(2)^2,x(2),1;x(3)^2,x(3),1];
        B = [y(1);y(2);y(3)];
        abc = linsolve(A,B);
        abc = abc';
        
        freqencyDop = -abc(2)/(2*abc(1));
        acqResults.codePhase(PRN) = codePhase;
        acqResults.carrFreq(PRN)  = freqencyDop;
%         %--- Save properties of the detected satellite signal -------------
%         acqResults.carrFreq(PRN)  = fftFreqBins(fftMaxIndex);
%         acqResults.codePhase(PRN) = codePhase;
%         acqResults.carrFreq(PRN)  = maxdoop;

    else
        %--- No signal with this PRN --------------------------------------
        fprintf('. ');
    end   % if (peakSize/secondPeakSize) > settings.acqThreshold
    
end    % for PRN = satelliteList

%=== Acquisition is over ==================================================
fprintf(')\n');
