load('detect_ds3_1to5');

%------------------------���Ƽ��ֵ------------------------------
channel = 4;
window = 19;
time_end = 400000;
for channelNr = 1:channel
figure(channelNr);
    plot(0,0,'r');
    hold on;
    plot(0,0,'b');
    hold on;
        legend('Judge As Spoofing Signal','Judge As Authentic Signal');
for i = 1:window:time_end
    if((i+window)>time_end)
       break; 
    end
%     if (detect(channelNr,i) == 0)      %��ɫ���ߴ�����ƭ
%     plot(i:(i+window),detect(channelNr,i:i+window),'-b');
%     hold on;
%     end
    if (detect(channelNr,i)>0)      %��ɫ���ߴ�����ƭ
        plot(i:(i+window),detect(channelNr,i:i+window),'-r');
        hold on;
    %     legend('Spoofing Signal');
    end
    if (detect(channelNr,i)<0 )%��ɫ����δ��⵽��ƭ
        plot(i:(i+window),detect(channelNr,i:i+window),'-b');
        hold on;
    %     legend('Authentic Signal');
    end
end
        xlabel('Time[ms]');
        ylabel('Proposed Detection Value');
end
%------------------------���Ʋ�ͬ���ڶԱ�------------------------------
% load('reg_500_ave_noise_power.mat');
% plot(ave_noise_power,'-b');
% hold on;
% load('reg_5000_ave_noise_power.mat');
% plot(ave_noise_power,'--r');

% load('slid_0_1_500_ave_noise_before_power.mat');
% load('slid_0_9_500_ave_noise_before_power.mat');
